import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const data = await request?.json?.();

    const {
      venueName = "",
      contactName = "",
      email = "",
      phone = "",
      venueType = "",
      immediateNeed = "no",
      message = "",
    } = data ?? {};

    // Validate required fields
    if (!venueName || !contactName || !email || !phone || !venueType) {
      return NextResponse.json(
        { success: false, message: "Missing required fields" },
        { status: 400 }
      );
    }

    // 1. Try to submit to Airtable
    let airtableSuccess = false;
    const airtableToken = process.env.AIRTABLE_ACCESS_TOKEN;
    const airtableBaseId = process.env.AIRTABLE_BASE_ID;

    if (airtableToken && airtableBaseId && airtableBaseId !== "YOUR_BASE_ID") {
      try {
        const airtableResponse = await fetch(
          `https://api.airtable.com/v0/${airtableBaseId}/venues`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${airtableToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              fields: {
                "Venue Name": venueName,
                "Contact Name": contactName,
                Email: email,
                Phone: phone,
                "Venue Type": venueType,
                "Immediate Need": immediateNeed === "yes" ? "Yes" : "No",
                Message: message,
                "Submitted At": new Date().toISOString(),
                Status: "New Lead",
              },
            }),
          }
        );

        if (airtableResponse?.ok) {
          airtableSuccess = true;
        } else {
          const errorData = await airtableResponse?.json?.();
          console.error("Airtable error:", errorData);
        }
      } catch (airtableError) {
        console.error("Airtable submission error:", airtableError);
      }
    }

    // 2. Send email notification
    let emailSuccess = false;
    const apiKey = process.env.ABACUSAI_API_KEY;

    if (apiKey) {
      try {
        const appUrl = process.env.NEXTAUTH_URL ?? "https://oncallnetwork.com.au";
        let hostname = "oncallnetwork.com.au";
        try {
          hostname = new URL(appUrl)?.hostname ?? "oncallnetwork.com.au";
        } catch {
          // Use default hostname
        }

        const urgencyBadge = immediateNeed === "yes" 
          ? '<span style="background: #dc2626; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold;">🚨 URGENT - NEEDS STAFF ASAP</span>'
          : '<span style="background: #059669; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px;">Planning Ahead</span>';

        const htmlBody = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9fafb; padding: 20px;">
            <div style="background: #1e3a5f; padding: 20px; border-radius: 10px 10px 0 0;">
              <h1 style="color: #d4a853; margin: 0; font-size: 24px;">🎯 New Venue Inquiry</h1>
              <p style="color: white; margin: 10px 0 0 0; opacity: 0.9;">On Call Network Lead</p>
            </div>
            
            <div style="background: white; padding: 25px; border-radius: 0 0 10px 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
              <div style="margin-bottom: 20px;">
                ${urgencyBadge}
              </div>
              
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666; width: 120px;">Venue:</td>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; color: #1e3a5f;">${venueName}</td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666;">Contact:</td>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${contactName}</td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666;">Email:</td>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="mailto:${email}" style="color: #d4a853;">${email}</a></td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666;">Phone:</td>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="tel:${phone}" style="color: #d4a853; font-weight: bold;">${phone}</a></td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666;">Venue Type:</td>
                  <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${venueType}</td>
                </tr>
              </table>
              
              ${message ? `
                <div style="margin-top: 20px; padding: 15px; background: #f9fafb; border-radius: 8px; border-left: 4px solid #d4a853;">
                  <p style="margin: 0 0 5px 0; color: #666; font-size: 12px; text-transform: uppercase;">Message</p>
                  <p style="margin: 0; color: #1e3a5f;">${message}</p>
                </div>
              ` : ""}
              
              <div style="margin-top: 25px; padding: 15px; background: #1e3a5f; border-radius: 8px; text-align: center;">
                <p style="color: #d4a853; margin: 0 0 10px 0; font-weight: bold;">📞 Follow up within 2 hours!</p>
                <a href="tel:${phone}" style="display: inline-block; background: #d4a853; color: #1e3a5f; padding: 10px 25px; border-radius: 5px; text-decoration: none; font-weight: bold;">Call ${contactName}</a>
              </div>
              
              <p style="color: #999; font-size: 12px; margin-top: 20px; text-align: center;">
                Submitted: ${new Date().toLocaleString("en-AU", { timeZone: "Australia/Sydney" })}
              </p>
            </div>
          </div>
        `;

        const emailResponse = await fetch(
          "https://apps.abacus.ai/api/sendNotificationEmail",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              deployment_token: apiKey,
              subject: `${immediateNeed === "yes" ? "🚨 URGENT: " : ""}New Venue Inquiry - ${venueName} (${venueType})`,
              body: htmlBody,
              is_html: true,
              recipient_email: "diegoauguin@gmail.com",
              sender_email: `noreply@${hostname}`,
              sender_alias: "On Call Network",
            }),
          }
        );

        const emailResult = await emailResponse?.json?.();
        if (emailResult?.success) {
          emailSuccess = true;
        } else {
          console.error("Email error:", emailResult);
        }
      } catch (emailError) {
        console.error("Email sending error:", emailError);
      }
    }

    // Return success if at least email was sent
    if (emailSuccess) {
      return NextResponse.json({
        success: true,
        message: "Thank you! We'll be in touch within 2 hours.",
        airtableSuccess,
        emailSuccess,
      });
    }

    // If nothing worked, still return success but log the issue
    console.warn("Form submission completed but integrations may have failed");
    return NextResponse.json({
      success: true,
      message: "Request received. We'll contact you soon.",
      airtableSuccess,
      emailSuccess,
    });

  } catch (error) {
    console.error("API route error:", error);
    return NextResponse.json(
      { success: false, message: "An error occurred. Please try again." },
      { status: 500 }
    );
  }
}
